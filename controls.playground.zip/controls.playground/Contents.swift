import UIKit

let yas = 13
if yas > 18 {
    print("yaşınız 18'den büyüktür")
}else {
    print("yaşınız 18'den küçüktür ")
}

let yas2 = 15
if yas2 < 0 {
    print("yaşınız 0 dan küçük olamaz")
}else if yas2>18 {
    print("yaşınız 18 den büyüktür")
}else {
    print("yaşınız 18 den küçüktür")
}

//eğer birden çok koşulu aynı if ile kontrol etmek istiyorsak koşulları mantıksal karşılaştırma operatörleri ile veya
//işareti ile ayırarak kontrol edebiliriz

let yas3 = 13
if yas3<0 , yas3>150 {
    print("yaşınız 0 dan küüçük veya 150 den büyük olamaz")
}else{
    print("yaş bilginiz doğrulandı")
}
