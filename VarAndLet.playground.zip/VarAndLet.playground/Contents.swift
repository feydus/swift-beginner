import UIKit

var greeting = "Hello " //tip belirtmek istediğinde var greeting : String = "hello" - değişken tanımlama şekli
//var yazıp değişkeni tanımladığında swift zaten onu biliyor bu yüzden tür belirtmeye gerek yok

let pi : Double = 3.14 //sabit tanımlama denir - swift bunun double bi değer olduğunu bilir fakat ben bu değeri float yapmak istediğimde değişiklik yapabilirim
//let pi : float = 3.14 gibi değiştirebilirim

var bosluk: String //boş bir değer tanımlarken o değerin hangi tip olduğunu tanımlamak gerekli

let isim = "kıymet"


print(greeting)
print(pi)
print(isim)
print("Hello \(isim)")
print("\(greeting)\(isim) ")
